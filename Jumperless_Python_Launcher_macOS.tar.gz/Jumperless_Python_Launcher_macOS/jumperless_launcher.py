#!/usr/bin/env python3
"""
Jumperless macOS Python Launcher Wrapper
Cross-platform launcher that can be executed directly
"""
import os
import sys
import subprocess

def main():
    """Main launcher function"""
    # Get script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("\\n" + "="*50)
    print("    Jumperless macOS Python Launcher")
    print("="*50 + "\\n")
    
    # Find Python
    python_cmd = None
    for cmd in ['python3', 'python']:
        try:
            result = subprocess.run([cmd, '--version'], 
                                  capture_output=True, check=True)
            python_cmd = cmd
            print(f"✅ Python found: {cmd}")
            break
        except Exception:
            continue
    
    if not python_cmd:
        print("❌ Python 3 not found")
        input("\\nPress Enter to exit...")
        return 1
    
    # Install requirements
    requirements_file = os.path.join(script_dir, 'requirements.txt')
    if os.path.exists(requirements_file):
        print("📦 Installing Python dependencies...")
        try:
            subprocess.run([python_cmd, '-m', 'pip', 'install', '-r', requirements_file], 
                          check=True)
            print("✅ Dependencies installed successfully")
        except subprocess.CalledProcessError:
            print("⚠️  Warning: Some dependencies may not have installed")
    
    # Run main application
    print("\\n🚀 Starting Jumperless Bridge...")
    
    main_script = os.path.join(script_dir, 'JumperlessWokwiBridge.py')
    if not os.path.exists(main_script):
        print(f"❌ Main script not found: {main_script}")
        input("Press Enter to exit...")
        return 1
    
    try:
        # Change to script directory and run
        os.chdir(script_dir)
        result = subprocess.run([python_cmd, 'JumperlessWokwiBridge.py'] + sys.argv[1:])
        return result.returncode
    except KeyboardInterrupt:
        print("\\n\\n⚠️  Interrupted by user")
        return 0
    except Exception as e:
        print(f"❌ Error running Jumperless: {e}")
        input("Press Enter to exit...")
        return 1

if __name__ == "__main__":
    sys.exit(main())
